//
//  foodDetails.swift
//  aggie tracks
//
//  Created by Avnoor Singh Sidhu on 5/20/23.
//

import SwiftUI

struct details: View {
    var body: some View {
        VStack {
            Capsule()
                .frame(width: 40, height: 6)
                .padding(.top, nil)
            Text("Egg")
            Text("Serving Size: 1")
            Text("Calories: 12")
            Text("Fat (g): 1")
            Text("Carbohydrates (g): 12")
            Text("Protein (g): 12")
        }
    }
}


struct details_Previews: PreviewProvider {
    static var previews: some View {
        details()
    }
}
