//
//  aggieTrackerApp.swift
//  aggieTracker
//
//  Created by Avnoor Singh Sidhu on 5/21/23.
//

import SwiftUI

@main
struct aggieTrackerApp: App {
    @StateObject var viewModel = ViewModel()
    init() {
        viewModel.login()
        }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
