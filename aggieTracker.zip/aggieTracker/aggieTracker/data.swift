//
//  sampleData.swift
//  aggie tracks
//
//  Created by Avnoor Singh Sidhu on 5/20/23.
//

import Foundation
import SwiftUI
import RealmSwift

let app = App(id: "moomooeatsdbconnect-vvxjb") // Replace with your App ID


struct Meal {
   let name: String
   let servingSize: String
   let cals: String
   let fat: String
   let protein: String
   let carbs: String
}

var meals: [Meal] = []

// Create an array of Person structs


class ViewModel: ObservableObject {
    @Published var user: User?

    func login(email: String = "rbudhiraja@ucdavis.edu", password: String = "grahamcracker23") {
        app.login(credentials: Credentials.emailPassword(email: email, password: password)) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    self?.user = user
                    // Authentication successful, perform any necessary actions
                case .failure(let error):
                    print("Login failed: \(error.localizedDescription)")
                    // Handle login failure
                }
            }
            
            
            
            // mongodb-atlas is the cluster service name
            let client = app.currentUser!.mongoClient("mongodb-atlas")
            // Select the database
            let database = client.database(named: "DCMacros")
            // Select the collection
            let collection = database.collection(withName: "Aggie")
            
            let queryFilter: Document = [:] // Empty filter to retrieve all documents
            collection.find(filter: queryFilter) { result in
                switch result {
                case .failure(let error):
                    print("Call to MongoDB failed: \(error.localizedDescription)")
                    return
                case .success(let documents):

                    for document in documents {
                        guard let nameBSON = document["name"] as? AnyBSON,
                              let name = nameBSON.stringValue else {
                            print("Error: Invalid or missing 'name' value")
                            continue
                        }
                        
                        guard let servingSizeBSON = document["servingSize"] as? AnyBSON,
                              let servingSize = servingSizeBSON.stringValue else {
                            print("Error: Invalid or missing 'servingSize' value")
                            continue
                        }
                        
                        guard let calsBSON = document["cals"] as? AnyBSON,
                              let cals = calsBSON.stringValue else {
                            print("Error: Invalid or missing 'cals' value")
                            continue
                        }
                        
                        guard let fatBSON = document["fat"] as? AnyBSON,
                              let fat = fatBSON.stringValue else {
                            print("Error: Invalid or missing 'fat' value")
                            continue
                        }
                        
                        guard let proteinBSON = document["protein"] as? AnyBSON,
                              let protein = proteinBSON.stringValue else {
                            print("Error: Invalid or missing 'protein' value")
                            continue
                        }
                        
                        guard let carbsBSON = document["carbs"] as? AnyBSON,
                              let carbs = carbsBSON.stringValue else {
                            print("Error: Invalid or missing 'carbs' value")
                            continue
                        }
                        
                        let meal = Meal(name: name, servingSize: servingSize, cals: cals, fat: fat, protein: protein, carbs: carbs)
                        meals.append(meal)
                    }

                    // Now you have the array of structs populated with the values from the documents


                    // Now you have the array of structs populated with the values from the documents

                    // Use the `myStructArray` for further processing
                    for meal in meals {
                        print("Name: \(meal.name)")
                        print("Serving Size: \(meal.servingSize)")
                        print("Calories: \(meal.cals)")
                        print("Fat: \(meal.fat)")
                        print("Protein: \(meal.protein)")
                        print("Carbs: \(meal.carbs)")
                        print("---")
                    }
                    print("Number of meals: \(meals.count)")
                }
            }
        }
    }
}
