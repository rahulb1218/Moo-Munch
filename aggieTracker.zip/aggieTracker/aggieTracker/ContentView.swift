//
//  ContentView.swift
//  aggieTracks
//
//  Created by Avnoor Singh Sidhu on 5/20/23.
//

import SwiftUI

struct ContentView: View {
    @State var searchText: String = ""
    @State var breakfastItems: [String] = []
    @State var lunchItems: [String] = []
    @State var dinnerItems: [String] = []
    @State var snacksItems: [String] = []
    @State var numCalories: Double = 0
    @State var cAloires: Double = 0
    @State var foodTracker: Int = 0
    @State var remainingTracker: Int = 2000
    var body: some View {
        NavigationView {
            ScrollView {
                mealView(meal: "Breakfast", numCalories: 400, items: $breakfastItems, numberOfCalories: $cAloires, foodTracker: $foodTracker, rm1: $remainingTracker)
                    .padding(.top)
                mealView(meal: "Lunch", numCalories: 700, items: $lunchItems, numberOfCalories: $cAloires, foodTracker: $foodTracker, rm1: $remainingTracker)
                mealView(meal: "Dinner", numCalories: 700, items: $dinnerItems, numberOfCalories: $cAloires, foodTracker: $foodTracker, rm1: $remainingTracker)
                mealView(meal: "Snacks", numCalories: 200, items: $snacksItems, numberOfCalories: $cAloires, foodTracker: $foodTracker, rm1: $remainingTracker)
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    HStack {
                        Spacer()
                        VStack {
                            Text("Budget: ")
                            Text("2000")
                        }
                        Spacer()
                        VStack {
                            Text("Food: ")
                            Text("\(foodTracker)")
                        }
                        Spacer()
                        VStack {
                            Text("Remaining: ")
                            Text("\(remainingTracker)")
                        }
                        Spacer()
                    }
                }
            }
        }
    }
}

struct mealView: View {
    var meal: String
    var numCalories: Int
    @State var showBreakfast = false
    @State var showLunch = false
    @State var showDinner = false
    @State var showSnacks = false
    @Binding var items: [String]
    @Binding var numberOfCalories: Double
    @Binding var foodTracker: Int
    @Binding var rm1: Int
    @State var breakfastCalories: Int = 0
    @State var lunchCalories: Int = 0
    @State var dinnerCalories: Int = 0
    @State var snackCalories: Int = 0
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25.0)
                .fill(Color.white)
//                .frame(height: UIScreen.main.bounds.maxY * 0.17)
                .padding(.trailing)
                .padding(.leading)
                .shadow(radius: 5)
            
            VStack(alignment: .leading) {
                Text(meal)
                    .font(.title)
                Text("\(numCalories) calories suggested")
                    .padding(.bottom)
                if !items.isEmpty {
                    ForEach(items, id: \.self) { index in
                        HStack {
                            Text("\(index)")
                                .font(.subheadline)
                            Spacer()
                            Button {
                                if let element = items.firstIndex(of: index) {
                                    items.remove(at: element)
                                }
                                var prevFood: Int = foodTracker
                                foodTracker -= Int(numberOfCalories)
                                rm1 += prevFood
                            } label: {
                                Image(systemName: "minus.circle")
                                    .padding(.trailing, 30)
                                    .padding(.bottom, 1)
                            }
                        }

                    }
                }
                
                Button(action: {
                    switch meal {
                    case "Breakfast":
                        self.showBreakfast = true
                    case "Lunch":
                        self.showLunch = true
                    case "Dinner":
                        self.showDinner = true
                    case "Snacks":
                        self.showSnacks = true
                    default:
                        break
                    }
                }) {
                    HStack {
                        Spacer()
                        NavigationLink(destination: breakfastView2(items: $items, numberCalories: $numberOfCalories, fd: $foodTracker, rm: $rm1)) {
                            VStack {
                                Spacer()
                                Text("Add \(meal)")
                                    .padding(.top, 5)
                                    .padding(.bottom, 5)
                                    .padding(.trailing)
                                    .padding(.leading)
                                    .background(
                                        Color.white
                                            .cornerRadius(10)
                                            .shadow(radius: 5)
                                    )
                                .padding(.trailing, 35)
                            }
                            .padding(.top)
                            .padding(.bottom)
                        }
                    }
                }
//                .popover(isPresented: popoverBinding) {
//                                    popoverContent()
//                }
            }
            .padding(.top)
            .padding(.leading, 30)
        }
    }
}

struct lunchView: View {
    var body: some View {
        Text("lunch")
    }
}

struct dinnerView: View {
    var body: some View {
        Text("dinner")
    }
}

struct snacksView: View {
    var body: some View {
        Text("snacks")
    }
}

struct topBar: View {
    var body: some View {
        HStack {
            Spacer()
            VStack {
                Text("Budget: ")
                Text("2000")
            }
            Spacer()
            VStack {
                Text("Food: ")
                Text("500")
            }
            Spacer()
            VStack {
                Text("Exercise: ")
                Text("100")
            }
            Spacer()
            VStack {
                Text("Net: ")
                Text("1600")
            }
            Spacer()
        }
        .padding(.bottom)
        .background(.gray.opacity(0.2))
    }
}

//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView(breakfastItems: breakfastItems, lunchItems: lunchItems, dinnerItems: dinnerItems, snacksItems: snacksItems)
//    }
//}

//    func popoverContent() -> some View {
//        if meal == "Breakfast" && showBreakfast {
////            return AnyView(breakfastView2())
//            return AnyView(breakfastView2())
//        } else if meal == "Lunch" && showLunch {
//            return AnyView(lunchView())
//        } else if meal == "Dinner" && showDinner {
//            return AnyView(dinnerView())
//        } else if meal == "Snacks" && showSnacks {
//            return AnyView(snacksView())
//        } else {
//            return AnyView(EmptyView())
//        }
//    }

//    var popoverBinding: Binding<Bool> {
//        Binding<Bool>(
//            get: {
//                switch meal {
//                case "Breakfast":
//                    return showBreakfast
//                case "Lunch":
//                    return showLunch
//                case "Dinner":
//                    return showDinner
//                case "Snacks":
//                    return showSnacks
//                default:
//                    return false
//                }
//            },
//            set: { value in
//                switch meal {
//                case "Breakfast":
//                    showBreakfast = value
//                case "Lunch":
//                    showLunch = value
//                case "Dinner":
//                    showDinner = value
//                case "Snacks":
//                    showSnacks = value
//                default:
//                    break
//                }
//            }
//        )
//    }
