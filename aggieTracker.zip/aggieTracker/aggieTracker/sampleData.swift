//
//  sampleData.swift
//  aggie tracks
//
//  Created by Avnoor Singh Sidhu on 5/20/23.
//

import Foundation

public var foodItems = [
    "coffee",
    "apple",
    "banana",
    "egg",
    "milk",
    "cha"
]
