//
//  breakfastView.swift
//  aggie tracks
//
//  Created by Avnoor Singh Sidhu on 5/20/23.
//

import SwiftUI

struct breakfastView2: View {
    @State private var searchText: String = ""
//    private var listOfFood = foodItems
//    private var listOfFood = meals
    @State var buttonPressed = false
    @State var selectedFood: String?
    @State var showThisFood: String = ""
    @State var currentDragOffset: CGFloat = 0
    @Binding var items: [String]
    @Binding var numberCalories: Double
    @Binding var fd: Int
    @Binding var rm: Int
    @StateObject var viewModel = ViewModel()
    public init(items: Binding<[String]>, numberCalories: Binding<Double>, fd: Binding<Int>, rm: Binding<Int>) {
            _items = items
            _numberCalories = numberCalories
            _fd = fd
            _rm = rm
        }
//    @State var isShowingPopup: Bool = false
    var body: some View {
        ZStack(alignment: .bottom) {
            NavigationView {
                List {
                    ForEach(food, id: \.self) { food in
                        foodView(food: food.capitalized, selectedFood: $selectedFood)
                    }
                }
                .searchable(text: $searchText)
                .navigationTitle("Food")
                .onChange(of: selectedFood) { newValue in
                    print("Selected food:", newValue!)
                    showThisFood = newValue!
                    buttonPressed = true
//                    isShowingPopup = true
                }
            }
//            var x = print("buttonPressed Value \(buttonPressed.description)")
            if buttonPressed {
                Color.black.opacity(0.3)
                    .onTapGesture {
                        animatePopUp()
                    }
                foodDetails(showPopup: $buttonPressed, selectedFoodItem: showThisFood, items: $items, numberCalories: $numberCalories, fd2: $fd, rm2: $rm)
                    .transition(.move(edge: .bottom))
                    .offset(y: currentDragOffset)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                withAnimation(.easeInOut) {
                                    if currentDragOffset < 0 {
                                        return
                                    }
                                    else {
                                        currentDragOffset = value.translation.height
                                    }
                                }
                            }
                            .onEnded { value in
                                withAnimation(.easeInOut) {
                                    if currentDragOffset < 0 {
                                        currentDragOffset = 0
                                    }
                                    else {
                                        currentDragOffset = 0
//                                        isShowingPopup = false
                                        buttonPressed = false
                                    }
                                }
                            }
                    )
            }
        }
        .ignoresSafeArea()
    }

//    var food: [String] {
//        let lcFood = listOfFood.map { $0.lowercased() }
//        return searchText == "" ? lcFood : lcFood.filter {
//            $0.contains(searchText.lowercased())
//        }
//    }
    
    var food: [String] {
//        viewModel.login()
        var mealNames: [String] = []
        for meal in meals {
            mealNames.append(meal.name)
            print(meal.name)
        }
        print("Size of mealNames:\(mealNames.count)")
        let lcFood = mealNames.map { $0.lowercased() }
        return searchText == "" ? lcFood : lcFood.filter {
            $0.contains(searchText.lowercased())
    }


    }
    
    func animatePopUp() {
        withAnimation(.easeInOut) {
            buttonPressed = false
        }
    }
}

var numCalories: Double = 0
var servingSize: String = ""
var fat: String = ""
var protein: String = ""
var carbs: String = ""

struct foodView: View {
    var food: String
    @Binding var selectedFood: String?
//    @State public var numCalories: Double = 0
//    @State public var servingSize: String = ""
//    @State public var fat: String = ""
//    @State public var protein: String = ""
//    @State public var carbs: String = ""
    var body: some View {

        Button {
            selectedFood = food
            if let meal = meals.first(where: { $0.name == food }) {
                numCalories = Double(meal.cals)!
                servingSize = meal.servingSize
                fat = meal.fat
                protein = meal.protein
                carbs = meal.carbs
                print("Calories for \(food): \(numCalories)")
            }
            
        } label: {
            HStack {
                VStack(alignment: .leading) {
                    Text(food)
                    
//                    Text("\(numCalories) calories")
                }
                Spacer()
                Image(systemName: "plus.circle")
            }
        }
    }
}

struct SearchBar: View {
    @Binding var searchText: String

    var body: some View {
        ZStack {
            TextField("Search food...", text: $searchText)
                .padding()
                .background(Color.gray.opacity(0.2).cornerRadius(10))
                .padding(.horizontal, 10)

            Button {
                searchText = ""
            } label: {
                HStack {
                    Spacer()
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                        .padding(8)
                }
                .padding(.trailing)
            }
        }
    }
}

struct foodDetails: View {
    @Binding var showPopup: Bool
    var selectedFoodItem: String
    @Binding var items: [String]
    @Binding var numberCalories: Double
    @Binding var fd2: Int
    @Binding var rm2: Int
//    @State var numCalories: Double = 0
    var body: some View {
        VStack() {
            Capsule()
                .frame(width: 40, height: 6)
                .foregroundColor(.black)
                .padding(.top, nil)
            VStack {
                HStack {
                    Spacer()
                    Text("\(selectedFoodItem)")
                        .font(.largeTitle)
                    Spacer()
                }
                VStack {
                    HStack {
                        VStack {
                            Text("Serving Size")
                            Text(servingSize)
                        }
                        Spacer()
                        VStack {
                            Text("Carbohydrates (g)")
                            Text(carbs)
                        }
                    }
                    .padding()
                }
                .font(.title2)
                VStack {
                    HStack {
                        VStack {
                            Text("Calories")
                            Text("\(numCalories)")
                        }
                        Spacer()
                        VStack {
                            Text("Protein (g)")
                            Text(protein)
                        }
                        Spacer()
                        VStack {
                            Text("Fat (g)")
                            Text(fat)
                        }
                    }
                    .padding()
                }
                .font(.title2)
                Button {
                    fd2 += Int(numCalories)
                    rm2 -= fd2
                    numberCalories = numCalories
                    items.append(selectedFoodItem)
                    animatePopUp()
                } label: {
                    Text("Add")
                        .font(.title2)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .foregroundColor(.white)
                                .shadow(radius: 5)
                        )
                        .padding(.top)
                }

            }
            Spacer()
        }
        .background(Color(.white))
        .frame(height: UIScreen.main.bounds.height * 0.50)
        .frame(width: UIScreen.main.bounds.width)
        .cornerRadius(30)
        .shadow(radius: 10)
    }
    func animatePopUp() {
        withAnimation(.easeInOut) {
            showPopup = false
        }
    }
}

//struct breakfastView2_Previews: PreviewProvider {
//    static var previews: some View {
////        breakfastView2()
////        foodDetails(selectedFoodItem: "Coffee")
//    }
//}
