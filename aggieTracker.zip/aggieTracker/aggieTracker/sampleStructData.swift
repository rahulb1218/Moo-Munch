//
//  sampleStructData.swift
//  aggieTracker
//
//  Created by Avnoor Singh Sidhu on 5/21/23.
//

import Foundation

public struct item {
    var name: String
    var serve: Int
    var carb: Int
    var cal: Int
    var protien: Int
    var fat: Int
    
}

// Create an array of Person structs
public var foodlist: [item] = []

// Add elements to the array
let item1 = item(name: "Coffee", serve: 100, carb: 40, cal: 10, protien: 20, fat: 8)
let item2 = item(name: "Apple", serve: 100, carb: 40, cal: 10, protien: 20, fat: 8)
let item3 = item(name: "Banana", serve: 100, carb: 40, cal: 10, protien: 20, fat: 8)
let item4 = item(name: "Egg", serve: 100, carb: 40, cal: 10, protien: 20, fat: 8)
let item5 = item(name: "Milk", serve: 100, carb: 40, cal: 10, protien: 20, fat: 8)
let item6 = item(name: "Cha", serve: 100, carb: 40, cal: 10, protien: 20, fat: 8)
